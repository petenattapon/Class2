function goBack() {
  window.history.go(-1);
}
function goForward() {
  window.history.go(1);
}
